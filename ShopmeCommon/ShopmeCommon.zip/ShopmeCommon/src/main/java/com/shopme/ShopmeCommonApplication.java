package com.shopme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopmeCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopmeCommonApplication.class, args);
	}

}
